@extends('template')

@section('content')
    <main class="block-online-main">
        <div class="block-online-body">
            <div class="block-online-content">
                <span class="block-services">Услуги</span>
                <span class="services-title">Еще нет услуг для заказа. Пожалуйста, зайдите позже.</span>
            </div>
        </div>
    </main>
@endsection


